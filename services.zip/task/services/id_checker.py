def is_in_range(id, task_list):
    '''Check if task id is in range'''
    return True