import json
import time


def update(args, file):
    '''Update task'''
    print(args.task_id)
    print(args.task)

def mark(args, file):
    '''Mark task as in progress or done'''
    print(args.task_id)