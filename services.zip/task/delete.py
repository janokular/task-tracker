import json


def delete(args, file):
    '''Delete task'''
    print(args.task_id)